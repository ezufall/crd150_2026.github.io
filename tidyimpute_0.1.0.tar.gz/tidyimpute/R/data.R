#' @docType data
#' @title data with missing values
#' 
#' @aliases nacars nacars_dt nairis nairis_dt
#' 
#' @details 
#' 
#' **cars** and **iris** data sets with missing data for demonstration purposes.
#' 
#' @md

"nacars"
