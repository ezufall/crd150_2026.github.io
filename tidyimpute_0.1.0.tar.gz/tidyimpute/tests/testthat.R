library(testthat)
library(tidyimpute)

test_check("tidyimpute")
